package com.requestmanagementsystem.service.impl;

import java.util.Collections;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.requestmanagementsystem.entity.Request;
import com.requestmanagementsystem.exception.NotFoundException;
import com.requestmanagementsystem.repository.RequestRepository;
import com.requestmanagementsystem.service.RequestService;

import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Service
public class RequestServiceImpl implements RequestService {

	final RequestRepository requestRepository;

	public RequestServiceImpl(RequestRepository requestRepository) {
		this.requestRepository = requestRepository;
	}

	@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
	@Override
	public List<Request> findAllRequests() {
		return requestRepository.findAll();
	}

	@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
	@Override
	public Request findRequestById(Long id) {
		return requestRepository.findById(id)
				.orElseThrow(() -> new NotFoundException(String.format("Request not found with ID %d", id)));
	}

	@Override
	public void createRequest(Request request) {
		if ("library".equalsIgnoreCase(request.getRequestType())) {
			callLibraryManagementService("borrow", request.getBookName());
		}
		long count = requestRepository.count();
		request.setId(count + 1);
		requestRepository.save(request);
	}

	@Override
	public void updateRequest(Request request) {
		requestRepository.save(request);
	}

	@Override
	public void deleteRequest(Long id) {
		var request = requestRepository.findById(id)
				.orElseThrow(() -> new NotFoundException(String.format("Request not found with ID %d", id)));
		if ("library".equalsIgnoreCase(request.getRequestType())) {
			callLibraryManagementService("return", request.getBookName());
		}
		requestRepository.deleteById(request.getId());
	}

	@Override
	public Page<Request> findPaginated(Pageable pageable) {

		var pageSize = pageable.getPageSize();
		var currentPage = pageable.getPageNumber();
		var startItem = currentPage * pageSize;
		List<Request> list;

		if (findAllRequests().size() < startItem) {
			list = Collections.emptyList();
		} else {
			var toIndex = Math.min(startItem + pageSize, findAllRequests().size());
			list = findAllRequests().subList(startItem, toIndex);
		}

		return new PageImpl<Request>(list, PageRequest.of(currentPage, pageSize), findAllRequests().size());

	}

	private void callLibraryManagementService(String action, String bookName) {
		RestTemplate restTemplate = new RestTemplate();

		MultiValueMap<String, String> requestParams = new LinkedMultiValueMap<>();
		requestParams.add("bookName", bookName);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(requestParams, headers);

		String url = "http://localhost:9080/book/" + action;
		restTemplate.exchange(url, HttpMethod.PUT, requestEntity, String.class);

	}

}
