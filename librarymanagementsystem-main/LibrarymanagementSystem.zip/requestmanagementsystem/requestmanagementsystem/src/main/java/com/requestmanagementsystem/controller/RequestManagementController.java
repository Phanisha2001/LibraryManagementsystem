package com.requestmanagementsystem.controller;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.requestmanagementsystem.entity.Request;
import com.requestmanagementsystem.service.RequestService;

import javax.servlet.http.HttpServletResponse;

@Controller
public class RequestManagementController {

	final RequestService requestService;

	public RequestManagementController(RequestService requestService) {
		this.requestService = requestService;
	}

	@GetMapping("/")
	public String index(HttpServletResponse res) {
		return "list-requests";
	}

	@RequestMapping("/requests")
	public String findAllRequests(Model model, @RequestParam("page") Optional<Integer> page,
			@RequestParam("size") Optional<Integer> size) {

		var currentPage = page.orElse(1);
		var pageSize = size.orElse(5);
		var bookPage = requestService.findPaginated(PageRequest.of(currentPage - 1, pageSize));

		model.addAttribute("requests", bookPage);

		int totalPages = bookPage.getTotalPages();
		if (totalPages > 0) {
			var pageNumbers = IntStream.rangeClosed(1, totalPages).boxed().collect(Collectors.toList());
			model.addAttribute("pageNumbers", pageNumbers);
		}
		return "list-requests";
	}

	@RequestMapping("/request/{id}")
	public String findRequestById(@PathVariable("id") Long id, Model model) {

		model.addAttribute("request", requestService.findRequestById(id));
		return "list-request";
	}

	@GetMapping("/addRequest")
	public String showCreateForm(Request request) {
		return "add-request";
	}

	@RequestMapping("/add-request")
	public String createRequest(Request request, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "add-request";
		}

		requestService.createRequest(request);
		model.addAttribute("request", requestService.findAllRequests());
		return "redirect:/requests";
	}

	@GetMapping("/updateRequest/{id}")
	public String showUpdateForm(@PathVariable("id") Long id, Model model) {

		model.addAttribute("request", requestService.findRequestById(id));
		return "update-request";
	}

	@RequestMapping("/update-request/{id}")
	public String updateRequest(@PathVariable("id") Long id, Request request, BindingResult result, Model model) {
		if (result.hasErrors()) {
			request.setId(id);
			return "update-request";
		}

		requestService.updateRequest(request);
		model.addAttribute("request", requestService.findAllRequests());
		return "redirect:/requests";
	}

	@RequestMapping("/remove-request/{id}")
	public String deleteRequest(@PathVariable("id") Long id, Model model) {
		requestService.deleteRequest(id);

		model.addAttribute("request", requestService.findAllRequests());
		return "redirect:/requests";
	}

}
