package com.requestmanagementsystem.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.requestmanagementsystem.entity.Request;

public interface RequestService {

	public List<Request> findAllRequests();

	public Request findRequestById(Long id);

	public void createRequest(Request request);

	public void updateRequest(Request request);

	public void deleteRequest(Long id);

	public Page<Request> findPaginated(Pageable pageable);

}
