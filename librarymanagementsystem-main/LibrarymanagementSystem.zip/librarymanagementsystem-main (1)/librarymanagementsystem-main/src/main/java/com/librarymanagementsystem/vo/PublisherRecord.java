package com.librarymanagementsystem.vo;

public record PublisherRecord(Long id, String name) {

}
