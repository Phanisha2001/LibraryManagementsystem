package com.librarymanagementsystem.vo;

public record BorrowRecord(Long id, String name) {

}



