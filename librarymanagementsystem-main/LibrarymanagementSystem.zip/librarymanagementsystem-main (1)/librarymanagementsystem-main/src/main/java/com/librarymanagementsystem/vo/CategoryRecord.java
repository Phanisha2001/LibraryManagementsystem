package com.librarymanagementsystem.vo;

public record CategoryRecord(Long id,String name) {

}
